document.addEventListener('DOMContentLoaded', function() {
   // Initialize Firebase with your configuration
   var firebaseConfig = {
    apiKey: "AIzaSyAO6q3B0EjaHSoiZ6ZaURQgL5pyczdNRzA",
authDomain: "pcos-97d37.firebaseapp.com",
projectId: "pcos-97d37",
storageBucket: "pcos-97d37.appspot.com",
messagingSenderId: "668305433114",
appId: "1:668305433114:web:c53689593bd04c13a467a3"
  };
  firebase.initializeApp(firebaseConfig);

  var db = firebase.firestore();

  // Define the predictPCOS function
  function predictPCOS(selectedSymptoms) {
    // Define the prediction rules
    var prediction = "";
    var additionalInfo = "";

    // ... (your existing prediction logic here) ...
if (
      (selectedSymptoms.includes('irregular periods') ||
        selectedSymptoms.includes('weight gain') ||
        selectedSymptoms.includes('acne') ||
        selectedSymptoms.includes('excessive hair growth')) &&
      selectedSymptoms.length >= 2
    ) {
      prediction = "High likelihood of PCOS";
      additionalInfo = "PCOS is a hormonal disorder common among women of reproductive age. It may cause irregular periods, weight gain, acne, and excessive hair growth.";
    } else if (
      ((selectedSymptoms.includes('acne') || selectedSymptoms.includes('oily skin')) &&
        (selectedSymptoms.includes('thinning hair or hair loss') || selectedSymptoms.includes('hair loss'))) ||
      (selectedSymptoms.includes('weight gain') && selectedSymptoms.length >= 2)
    ) {
      prediction = "Medium likelihood of PCOS";
      additionalInfo = "PCOS is a hormonal disorder common among women of reproductive age. It may cause acne, oily skin, thinning hair or hair loss, and weight gain.";
    } else if (selectedSymptoms.includes('mood swings') || selectedSymptoms.includes('irritability')) {
      prediction = "Low likelihood of PCOS";
      additionalInfo = "Mood swings and irritability can be caused by various factors and may not necessarily indicate PCOS. Consider consulting a healthcare professional for a proper diagnosis.";
    } else {
      prediction = "No specific prediction based on the selected symptoms";
      additionalInfo = "The selected symptoms do not provide enough information to make a prediction about PCOS. It is advisable to consult a healthcare professional for a proper evaluation.";
    }

    // Return the prediction result without creating the chart
    return { prediction: prediction, additionalInfo: additionalInfo };
  }

  // Attach submit event listener to symptomForm
  var symptomForm = document.getElementById('symptomForm');
  symptomForm.addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission

    // Get the selected symptoms
    var selectedSymptoms = [];
    var checkboxes = document.getElementsByName('symptom');

    for (var i = 0; i < checkboxes.length; i++) {
      if (checkboxes[i].checked) {
        selectedSymptoms.push(checkboxes[i].value);
      }
    }

    // Call the predictPCOS() function with the selected symptoms
    var prediction = predictPCOS(selectedSymptoms);

    // Get the predictionResult element
    var predictionResultElement = document.getElementById('predictionResult');

    // Display the prediction result
    predictionResultElement.innerHTML = '<p>Prediction: ' + prediction.prediction + '</p><p>' + prediction.additionalInfo + '</p>';

    // Create a canvas element for the chart
    var chartCanvas = document.createElement('canvas');
    chartCanvas.id = 'predictionChart';
    predictionResultElement.appendChild(chartCanvas);

    // Calculate prediction likelihoods
    var highLikelihood = prediction.prediction === "High likelihood of PCOS" ? 70 : 0;
    var mediumLikelihood = prediction.prediction === "Medium likelihood of PCOS" ? 20 : 0;
    var lowLikelihood = prediction.prediction === "Low likelihood of PCOS" ? 5 : 0;
    var noneLikelihood = prediction.prediction === "No specific prediction based on the selected symptoms" ? 5 : 0;

    // Create a bar chart using Chart.js
    var ctx = chartCanvas.getContext('2d');
    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['High', 'Medium', 'Low', 'None'],
        datasets: [{
          label: 'Prediction Likelihood',
          data: [highLikelihood, mediumLikelihood, lowLikelihood, noneLikelihood],
          backgroundColor: ['red', 'orange', 'yellow', 'green']
        }]
      },
      options: {
        scales: {
          y: {
            beginAtZero: true,
            max: 100,
            title: {
              display: true,
              text: 'Likelihood (%)'
            }
          }
        }
      }
    });
    // Retrieve the user's unique ID or use your own method to get the user's ID
    var user = firebase.auth().currentUser;
    var userId = user ? user.uid : null;

    // Now, add the code to update Firestore with user details and prediction result
    var userDetailsRef = db.collection("user_details").doc(userId);
    userDetailsRef.get().then(function(doc) {
      if (doc.exists) {
        var userDetails = doc.data();
        var userName = userDetails.name;
        var userAge = userDetails.age;
        var pcosHistory = userDetails.pcosHistory;

        // Update Firestore with the prediction result and date
        db.collection("user_details").doc(userId).update({
          predictionResult: prediction.prediction,
          predictionDate: new Date().toLocaleDateString()
        })
        .then(function() {
          console.log("Prediction result and date updated in Firestore.");
          var successMessageElement = document.getElementById('successMessage');
          successMessageElement.innerHTML = 'Prediction result and date updated in Firestore.';
          
        })
        .catch(function(error) {
          console.error("Error updating prediction result and date in Firestore: ", error);
        });
      } else {
        console.log("User details not found.");
      }
    }).catch(function(error) {
      console.log("Error getting user details from Firestore: ", error);
    });

    return false; // Prevent form submission and page reload
  });
});
