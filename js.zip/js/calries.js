document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('calculate').addEventListener('click', function () {
        const gender = document.getElementById('gender').value;
        const age = parseFloat(document.getElementById('age').value);
        const weight = parseFloat(document.getElementById('weight').value);
        const weightUnit = document.getElementById('weight-unit').value;
        const heightFeet = parseFloat(document.getElementById('height-feet').value);
        const heightInches = parseFloat(document.getElementById('height-inches').value);
        const heightCm = parseFloat(document.getElementById('height-cm').value);
        const activityLevel = document.getElementById('activity-level').value;

        // Convert height to centimeters
        const heightCmTotal = (heightFeet * 30.48) + (heightInches * 2.54);

        // Convert weight to kilograms if it's in pounds
        const weightKg = weightUnit === 'lb' ? weight * 0.45 : weight;

        let bmr;

        if (gender === "female") {
            bmr = 10 * weightKg + 6.25 * heightCmTotal - 5 * age - 161;
        }

        let calorieNeeds;

        switch (activityLevel) {
            case "sedentary":
                calorieNeeds = bmr * 1.2;
                break;
            case "lightly-active":
                calorieNeeds = bmr * 1.375;
                break;
            case "moderately-active":
                calorieNeeds = bmr * 1.55;
                break;
            case "very-active":
                calorieNeeds = bmr * 1.725;
                break;
            default:
                calorieNeeds = 0;
        }

        document.getElementById("calories").textContent = calorieNeeds.toFixed(2);
    });
});
