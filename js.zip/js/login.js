document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.getElementById("login-form");
    const loginMessage = document.getElementById("login-message");

    loginForm.addEventListener("submit", function (event) {
        event.preventDefault();
        const email = loginForm.querySelector("#email").value;
        const password = loginForm.querySelector("#password").value;

        firebase.auth().signInWithEmailAndPassword(email, password)
            .then(function (userCredential) {
                // Login successful
                loginMessage.textContent = "Login successful!";
                // Redirect the user to the data entry form
                window.location.href = "user-details.html";
            })
            .catch(function (error) {
                // Handle errors
                const errorCode = error.code;
                const errorMessage = error.message;
                console.error("Login failed:", errorCode, errorMessage);
                loginMessage.textContent = "Login failed: " + errorMessage;
            });
    });
});