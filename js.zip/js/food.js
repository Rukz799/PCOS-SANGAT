document.addEventListener('DOMContentLoaded', function() {
    const foodType = document.getElementById('foodType');
    const foodName = document.getElementById('foodName');
    const foodAmount = document.getElementById('foodAmount');
    const calculateButton = document.getElementById('calculate');
    const caloriesDisplay = document.getElementById('calories');

    // Dummy calorie values per gram/liter for each food type
    const calorieValues = {
        fruit: 0.5,
        vegetable: 0.2,
        dairy: 0.6,
    };

    calculateButton.addEventListener('click', function() {
        const selectedFoodType = foodType.value;
        const food = foodName.value.toLowerCase(); // Assuming food names are lowercase
        const amount = parseFloat(foodAmount.value);
        let calories = 0;

        if (!isNaN(amount) && calorieValues[selectedFoodType]) {
            // Replace this with a real database or API query
            calories = amount * calorieValues[selectedFoodType];
        } else {
            caloriesDisplay.textContent = 'Invalid input';
            return;
        }

        caloriesDisplay.textContent = `${calories.toFixed(2)} kcal`;
    });
});
