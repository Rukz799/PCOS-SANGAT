// registration.js
document.addEventListener("DOMContentLoaded", function () {
    const registrationForm = document.getElementById("registration-form");
    const registrationMessage = document.getElementById("registration-message");

    registrationForm.addEventListener("submit", function (event) {
        event.preventDefault();
        const email = registrationForm.querySelector("#email").value;
        const password = registrationForm.querySelector("#password").value;

        firebase.auth().createUserWithEmailAndPassword(email, password)
            .then(function (userCredential) {
                // Registration successful
                registrationMessage.textContent = "Registration successful!";
                window.location.href = "pcos prediction.html"; // Redirect to index.html after successful submission
            })
            .catch(function (error) {
                // Handle errors
                const errorCode = error.code;
                const errorMessage = error.message;
                console.error("Registration failed:", errorCode, errorMessage);
                registrationMessage.textContent = "Registration failed: " + errorMessage;
            });
    });
});
