// firebase-config.js
var firebaseConfig = {
    apiKey: "AIzaSyAO6q3B0EjaHSoiZ6ZaURQgL5pyczdNRzA",
    authDomain: "pcos-97d37.firebaseapp.com",
    projectId: "pcos-97d37",
    storageBucket: "pcos-97d37.appspot.com",
    messagingSenderId: "668305433114",
    appId: "1:668305433114:web:c53689593bd04c13a467a3",
    measurementId: "G-YSNDVYHY83"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
