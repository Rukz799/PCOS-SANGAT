document.addEventListener('DOMContentLoaded', function() {
    const trackButton = document.getElementById('track-button');
    const startDateInput = document.getElementById('start-date');
    const resultDiv = document.getElementById('result');

    trackButton.addEventListener('click', function() {
        const startDate = new Date(startDateInput.value);
        const cycleLength = 28; // Average menstrual cycle length in days

        const nextPeriodStartDate = new Date(startDate);
        nextPeriodStartDate.setDate(startDate.getDate() + cycleLength);

        resultDiv.innerHTML = `
            <p>Your next period is expected on ${nextPeriodStartDate.toDateString()}.</p>
        `;
    });
});
