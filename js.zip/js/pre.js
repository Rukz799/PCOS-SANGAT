document.addEventListener("DOMContentLoaded", function () {
    const dataEntryForm = document.getElementById("symptomForm");
    const dataEntryMessage = document.getElementById("data-entry-message");

    dataEntryForm.addEventListener("submit", function (event) {
        event.preventDefault();
        // Get the form data
        const formData = new FormData(dataEntryForm);
        const data = Object.fromEntries(formData.entries());

        // Get the current user
        const user = firebase.auth().currentUser;

        // Store the data in Firestore
        firebase.firestore().collection("data").add({
            ...data,
            userId: user.uid,
            timestamp: firebase.firestore.FieldValue.serverTimestamp()
        }).then(function () {
            // Reset the form
            dataEntryForm.reset();
            dataEntryMessage.textContent = "Data stored successfully";
        }).catch(function (error) {
            dataEntryMessage.textContent = "Error storing data: " + error.message;
        });
    });
});