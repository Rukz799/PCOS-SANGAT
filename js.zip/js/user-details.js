// user-details.js
document.addEventListener("DOMContentLoaded", function () {
  const userDetailsForm = document.getElementById("user-details-form");
  const userDetailsMessage = document.getElementById("user-details-message");

  // Get a reference to the Firestore database
  var db = firebase.firestore();

  // Listen for authentication state changes
  firebase.auth().onAuthStateChanged(function (user) {
    if (user) {
      // User is logged in, allow form submission
      userDetailsForm.addEventListener("submit", function (event) {
        event.preventDefault();

        // Get user input from form fields
        const name = userDetailsForm.querySelector("#name").value;
        const age = userDetailsForm.querySelector("#age").value;
        const pcosHistory = userDetailsForm.querySelector("#pcos-history").value;

        // Access the currently logged-in user
        const userId = user.uid;

        // Create a reference to the Firestore collection where you want to store the data (e.g., "user_details")
        const userDetailRef = db.collection("user_details").doc(userId);

        // Set the data in Firestore
        userDetailRef
          .set({
            name: name,
            age: age,
            pcosHistory: pcosHistory,
            // Add more fields here
          })
          .then(() => {
            userDetailsMessage.textContent = "Details stored successfully!";
            window.location.href = "index.html"; // Redirect to index.html after successful submission
          })
          .catch((error) => {
            console.error("Error storing details:", error);
            userDetailsMessage.textContent = "Error storing details: " + error.message;
          });
      });
    } else {
      // User is not logged in, handle this case as needed
      userDetailsMessage.textContent = "Please log in before entering details.";
    }
  });
});