// details.js
document.addEventListener("DOMContentLoaded", function () {
    const detailsForm = document.getElementById("details-form");
    const detailsMessage = document.getElementById("details-message");
  
    detailsForm.addEventListener("submit", function (event) {
      event.preventDefault();
  
      // Get user input from form fields
      const name = detailsForm.querySelector("#name").value;
      const age = detailsForm.querySelector("#age").value;
      const disease = detailsForm.querySelector("#disease").value;
      // Add more fields as needed
  
      // Get a reference to the Firestore database
      var db = firebase.firestore();
  
      // Access the currently logged-in user
      const user = firebase.auth().currentUser;
  
      if (user) {
        // User is logged in, proceed to store data in Firestore
        const userId = user.uid;
  
        // Create a reference to the Firestore collection where you want to store the data (e.g., "user_details")
        const userDetailRef = db.collection("user_details").doc(userId);
  
        // Set the data in Firestore
        userDetailRef
          .set({
            name: name,
            age: age,
            // Add more fields here
          })
          .then(() => {
            detailsMessage.textContent = "Details stored successfully!";
          })
          .catch((error) => {
            console.error("Error storing details:", error);
            detailsMessage.textContent = "Error storing details: " + error.message;
          });
      } else {
        // User is not logged in, handle this case as needed
        detailsMessage.textContent = "Please log in before entering details.";
      }
    });
  });