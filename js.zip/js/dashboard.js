document.addEventListener("DOMContentLoaded", function () {
  const displayName = document.getElementById("display-name");
  const displayAge = document.getElementById("display-age");
  const displayPcosHistory = document.getElementById("display-pcos-history");
  const displayPredictionDate = document.getElementById("display-prediction-date");
  const displayPredictionResult = document.getElementById("display-prediction-result");

  console.log("Checking user authentication state...");

  // Get a reference to the Firestore database
  var db = firebase.firestore();

  // Wait for the DOM content to load before listening for authentication state changes
  firebase.auth().onAuthStateChanged(function (user) {
    if (user) {
      console.log("User is logged in:", user);

      // User is logged in, retrieve data from Firestore
      const userId = user.uid;

      // Create a reference to the Firestore collection where the user details are stored
      const userDetailRef = db.collection("user_details").doc(userId);

      // Retrieve the user details from Firestore
      userDetailRef
        .get()
        .then((doc) => {
          if (doc.exists) {
            // Document exists, display the details
            console.log("User details found:", doc.data());

            const userDetails = doc.data();
            displayName.textContent = userDetails.name;
            displayAge.textContent = userDetails.age;
            displayPcosHistory.textContent = userDetails.pcosHistory;
            displayPredictionDate.textContent = userDetails.predictionDate;
            displayPredictionResult.textContent = userDetails.predictionResult;
            
          } else {
            // Document does not exist, handle this case as needed
            console.log("User details not found");
          }
        })
        .catch((error) => {
          console.error("Error retrieving user details:", error);
        });
    } else {
      // User is not logged in, handle this case as needed
      console.log("User not logged in");
    }
  });
});