

document.addEventListener("DOMContentLoaded", function () {
    const calculateButton = document.getElementById("calculate");
    const exerciseSelect = document.getElementById("exercise");
    const durationInput = document.getElementById("duration");
    const caloriesBurnedResult = document.getElementById("caloriesBurned");

    const exerciseData = {
        briskWalking: 300,  // Calories burned per hour
        running: 600,
        cycling: 500,
        swimming: 700,

        pushUps: 350,
        squats: 250,
        lunges: 300,
        planks: 200,

        weightlifting: 400,
        resistanceBands: 300,

        yoga: 200,
        pilates: 250,
        taiChi: 150,

        aerobicWorkouts: 500,
        hiit: 700,

        resistanceTraining: 400,

        hathaYoga: 150,
        vinyasaYoga: 300,
        ashtangaYoga: 400,
        bikramYoga: 450,

        mindfulnessMeditation: 50,
        transcendentalMeditation: 75,
        guidedMeditation: 60,
        yogaNidra: 90,
    };

    calculateButton.addEventListener("click", function () {
        const selectedExercise = exerciseSelect.value;
        const exerciseDuration = parseInt(durationInput.value);

        if (isNaN(exerciseDuration) || exerciseDuration <= 0) {
            alert("Please enter a valid exercise duration.");
            return;
        }

        if (exerciseData[selectedExercise]) {
            const caloriesBurned = (exerciseData[selectedExercise] / 60) * exerciseDuration;
            caloriesBurnedResult.textContent = caloriesBurned.toFixed(2);
        } else {
            alert("Invalid exercise selection.");
        }
    });
});
